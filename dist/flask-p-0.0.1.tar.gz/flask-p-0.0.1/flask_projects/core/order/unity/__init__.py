from flask_projects.core.order.unity.run import run
from flask_projects.core.order.unity.shell import shell

orders = [
    shell, run
]
