import uuid


def get_name():

    return uuid.uuid4()


name_extend = get_name()
